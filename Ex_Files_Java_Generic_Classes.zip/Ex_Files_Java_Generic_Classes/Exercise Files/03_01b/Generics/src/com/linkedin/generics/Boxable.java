package com.linkedin.generics;

public interface Boxable {
    public double getWeight();
}
