package com.linkedin.generics;

public class Apple extends Fruit{
    public Apple(String name, String countryOfOrigin, String colour, double weight) {
        super(name, countryOfOrigin, colour, weight);
    }
}
